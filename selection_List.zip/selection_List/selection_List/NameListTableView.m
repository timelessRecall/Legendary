//
//  NameListTableView.m
//  selection_List
//
//  Created by NTMC_MacMini on 2017/6/16.
//  Copyright © 2017年 bruce. All rights reserved.
//

#import "NameListTableView.h"

#import "ListTableViewCell.h"
@interface NameListTableView ()<UITableViewDelegate,
                              UITableViewDataSource,ListTableDelegate>

@property(nonatomic ,strong) NSMutableArray *deleteArry;//要显示的数组

@end

@implementation NameListTableView

-(instancetype)initWithFrame:(CGRect)frame style:(UITableViewStyle)style{

    self = [super initWithFrame:frame style:style];
    if (self) {

    self.dataSource = self;
    self.delegate = self;
 
    }

    return self;

}
//NOTE: 默认选中的人物,在这里赋值
-(void)setSelectArr:(NSArray *)selectArr{
  
    [self.deleteArry addObjectsFromArray:selectArr];
    self.block(self.deleteArry);
}
#pragma mark ============== tableView 代理方法 ====================
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 44;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    
    
    return 5;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    
    
    return 5;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    
    return _allDataArr.count;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{

    return 1;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    ListTableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    if (!cell) {
        
    cell = [[[NSBundle mainBundle]loadNibNamed:@"ListTableViewCell" owner:nil options:nil ]lastObject];
    }
    NSDictionary *dic = _allDataArr[indexPath.row];
    cell.nameLab.text = dic[@"USER_NAME"];
    cell.indexRow = indexPath.row;
    cell.delegate = self;
  
//NOTE: 默认选中的人物,在此打对勾
    if ([self.deleteArry containsObject: dic]){
    
    cell.seleBtn.selected = NO;
    }else{
    
    cell.seleBtn.selected = YES;
    }
    
    return cell;
}
//NOTE: 处理cell的点击
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    ListTableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    if (cell.seleBtn.selected != YES) {
//NOTE: 删除
        cell.seleBtn.selected = YES;
       [self.deleteArry removeObject:_allDataArr[indexPath.row]];
    }else{
//NOTE: 添加
        [self.deleteArry addObject:_allDataArr[indexPath.row]];
        cell.seleBtn.selected = NO;
    }
     self.block(self.deleteArry);
}
#pragma mark ========== 代理方法传进来点击的cell的下标和按钮的选中状态 ============
-(void) ListTableDelegate:(NSInteger )indexRow isRemov:(BOOL) is_remove{

    if (is_remove == YES) {
    
//NOTE: 删除
        [self.deleteArry removeObject:_allDataArr[indexRow]];
    }else{
//NOTE: 添加
        [self.deleteArry addObject:_allDataArr[indexRow]];

    }
    
    self.block(self.deleteArry);

}


-(NSMutableArray *)deleteArry{
    
    if (!_deleteArry) {
        _deleteArry = [NSMutableArray array];
    }
    return _deleteArry;

}
@end
