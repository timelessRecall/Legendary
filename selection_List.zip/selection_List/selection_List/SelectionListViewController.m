//
//  SelectionListViewController.m
//  selection_List
//
//  Created by NTMC_MacMini on 2017/6/16.
//  Copyright © 2017年 bruce. All rights reserved.
//
//[self.tableView setTableHeaderView:self.myTableviewFooter];
#import "SelectionListViewController.h"
#import "NameListTableView.h"
#import "HeaderView.h"

@interface SelectionListViewController ()<headerDelegate>
{

    NSMutableArray *dataArr;
}
@property (nonatomic ,strong) HeaderView *headerView;
@property (nonatomic ,strong) NameListTableView *userNameListTableView;
@end

@implementation SelectionListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = Color(235, 235, 235);
//NOTE: 数据源
    NSString *pathStr = [[NSBundle mainBundle] pathForResource:@"userData" ofType:@"plist"];
    NSData *myEncodedObject = [NSData dataWithContentsOfFile:pathStr];
    dataArr = [NSKeyedUnarchiver unarchiveObjectWithData: myEncodedObject];
    NSLog(@"%@",dataArr);
    [self AoutlayoutView];
    
}
//NOTE: 界面
-(void)AoutlayoutView{

    _userNameListTableView = [[NameListTableView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT) style:UITableViewStylePlain];
    _userNameListTableView.allDataArr = dataArr;
       [self.view addSubview:_userNameListTableView];
    _headerView = [[HeaderView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 0)];
    _headerView.delegate = self;
    _userNameListTableView.tableHeaderView = _headerView;
    __block NameListTableView *__blockTableView = _userNameListTableView;
    __block HeaderView *__blockHeaderView = _headerView;
//NOTE: 选中按钮进行回调
    _userNameListTableView.block = ^(NSMutableArray *seleArr){
   
        __blockHeaderView.headerDataArr = seleArr;

        [__blockTableView beginUpdates];
        [__blockTableView setTableHeaderView:__blockHeaderView];
        [__blockTableView endUpdates];

    };
     _userNameListTableView.selectArr = [dataArr subarrayWithRange:NSMakeRange(5, 10)];

}
//NOTE: 点击顶部按钮回调
#pragma mark ======= 点击按钮的处理方法 ========
-(void)BtnActionDelegate:(NSMutableArray *)arr{

    NSLog(@"%@",arr);
    _headerView.headerDataArr = arr;
    _userNameListTableView.BtnActionArr = [NSArray arrayWithArray:arr];
    [_userNameListTableView beginUpdates];
    [_userNameListTableView setTableHeaderView:_headerView];
    [_userNameListTableView endUpdates];
    
}


@end
