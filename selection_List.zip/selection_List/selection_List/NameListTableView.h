//
//  NameListTableView.h
//  selection_List
//
//  Created by NTMC_MacMini on 2017/6/16.
//  Copyright © 2017年 bruce. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HeaderView.h"

typedef void(^HeaderBlock)(NSMutableArray *);


@interface NameListTableView : UITableView
//NOTE: 所有的数据
@property (nonatomic ,strong) NSMutableArray *allDataArr;

@property (nonatomic ,copy) NSArray *selectArr;//默认的按钮
//NOTE: 回调
@property (nonatomic ,copy) HeaderBlock block;

@end
