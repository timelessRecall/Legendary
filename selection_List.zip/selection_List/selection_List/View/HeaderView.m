//
//  HeaderView.m
//  selection_List
//
//  Created by NTMC_MacMini on 2017/6/16.
//  Copyright © 2017年 bruce. All rights reserved.
//



#import "HeaderView.h"

@implementation HeaderView

-(instancetype)initWithFrame:(CGRect)frame{


    self = [super initWithFrame:frame];
    
    if (self) {
        
    self.backgroundColor = Color(235, 235, 235);
        
    }

    return self;
}


-(void)setHeaderDataArr:(NSMutableArray *)headerDataArr{
    [self.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    _headerDataArr = headerDataArr;
    [self readNameBtn];
    
}

-(void)readNameBtn{
    CGFloat BtnX = 0;
    CGFloat BtnY = Spacing;
    CGFloat BtnH = 40;
    for (int i = 0; i < _headerDataArr.count; i++) {
        
        UIButton *titBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        titBtn.backgroundColor = [UIColor whiteColor];
        //NOTE: 设置按钮的样式
        [titBtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        titBtn.titleLabel.font = [UIFont systemFontOfSize:17];
        NSDictionary *dic = _headerDataArr[i];
        [titBtn setTitle:dic[@"USER_NAME"] forState:UIControlStateNormal];
        titBtn.tag = 1000+i;
        [titBtn addTarget:self action:@selector(titBtnClike:) forControlEvents:UIControlEventTouchUpInside];
        UIImageView *imageView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"icon_pay_wrong"]];
        titBtn.imageEdgeInsets = UIEdgeInsetsMake(0, titBtn.height, titBtn.width, 0);
        
        //NOTE: 计算文字大小
        CGSize titleSize = [dic[@"USER_NAME"] boundingRectWithSize:CGSizeMake(MAXFLOAT,BtnH) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:titBtn.titleLabel.font} context:nil].size;
        CGFloat titBtnW = titleSize.width + 2 * Spacing; //按钮的长度加间距
        //NOTE: 判断按钮是否超过屏幕的宽
        if ((BtnX + titBtnW) > SCREEN_WIDTH) {
            BtnX = 0;
            BtnY += BtnH + Spacing;
        }
        //NOTE: 设置按钮的位置
        titBtn.frame = CGRectMake(BtnX, BtnY, titBtnW, BtnH);
        imageView.frame = CGRectMake(titBtn.width-10, 0, 10, 10);
        [titBtn addSubview:imageView];
 
        BtnX += titBtnW + Spacing;

        self.frame = CGRectMake(0, 0, SCREEN_WIDTH, BtnY + BtnH + 10);

        [self addSubview:titBtn];
        
    }
    if (_headerDataArr.count == 0) {
        
        self.frame = CGRectMake(0, 0, SCREEN_WIDTH, 0);
     
    }
}
-(void)titBtnClike:(UIButton *)sender{
   
    [_headerDataArr removeObjectAtIndex:sender.tag - 1000];
    [self.delegate BtnActionDelegate:_headerDataArr];

}


@end
